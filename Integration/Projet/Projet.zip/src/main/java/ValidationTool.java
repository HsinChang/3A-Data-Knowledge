import com.wcohen.ss.JaroWinkler;
import org.apache.jena.rdf.model.*;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.LinkedList;
import java.util.List;
import java.util.Random;

public class ValidationTool {

    public static void main(String[] args) throws IOException {


        //initialization read files
        Model model0 = ModelFactory.createDefaultModel();
        model0.read("IIMB_LARGE/000/onto.owl");

        Model model1 = ModelFactory.createDefaultModel();
        model1.read("IIMB_LARGE/001/onto.owl");

        List<String> functionalProperties = Files.readAllLines(Paths.get("fps.txt"));
        Model modelPairs = ModelFactory.createDefaultModel();
        modelPairs.read("IIMB_LARGE/001/refalign.rdf");

        //TODO: better to use SPARQL to retrieve the data, I have no time to test, follow this link: https://jena.apache.org/documentation/query/app_api.html
        //get correct correctPairs
        String propEntity1 = "http://knowledgeweb.semanticweb.org/heterogeneity/alignment#entity1";
        String propEntity2 = "http://knowledgeweb.semanticweb.org/heterogeneity/alignment#entity2";

        String entity1 = null;
        String entity2 = null;

        StmtIterator itr = modelPairs.listStatements();
        List<Pair> correctPairs = new LinkedList<>();

        while (itr.hasNext()) {
            Statement st = itr.nextStatement();

            String pred = st.getPredicate().toString();
            String obj = st.getObject().toString();

            if (pred.equalsIgnoreCase(propEntity1)) {
                entity1 = obj;
            }
            if (pred.equalsIgnoreCase(propEntity2)) {
                entity2 = obj;
            }

            if (entity1 != null && entity2 != null) {
                Pair pair = new Pair(entity1, entity2, true);
                correctPairs.add(pair);
                entity1 = null;
                entity2 = null;
            }
        }

        //generate random erroneous sameAs links
        List<Pair> incorrectPairs = new LinkedList<>();
        int numberOfErroneousLinks = 1000; //parameter that can be modified
        Random random = new Random();
        for (int i=0; i<numberOfErroneousLinks; i++) {
            int idx1 = random.nextInt(correctPairs.size());
            entity1 = correctPairs.get(idx1).getEntity1();
            //make sure that the second random number is different
            int idx2 = 0;
            do{
                idx2 = random.nextInt(correctPairs.size());
            }while(idx2==idx1);
            entity2 = correctPairs.get(idx2).getEntity2();
            incorrectPairs.add(new Pair(entity1, entity2, false));
        }

        //try the validation with the two groups of pairs
        //TODO: should use SPARQL instead
        double similarityThreshold = 0.7; //parameter modifiable TODO:参数可以多试试
        double truePositive = 0;
        double falsePositive = 0;
        double trueNegative = 0;
        double falseNegative = 0;

        for (Pair pair : correctPairs) {
            boolean same = true;
            Resource resource1 = model0.getResource(pair.getEntity1());
            StmtIterator it1 = resource1.listProperties();
            while (it1.hasNext()) {
                Statement st1 = it1.nextStatement();
                if (functionalProperties.contains(st1.getPredicate().toString())) {
                    String str1 = st1.getObject().toString();
                    Resource resource2 = model1.getResource(pair.getEntity2());
                    StmtIterator it2 = resource2.listProperties();
                    while (it2.hasNext()) {
                        Statement st2 = it2.nextStatement();
                        if (st2.getPredicate().toString().equals(st1.getPredicate().toString())) {
                            String str2 = st2.getObject().toString();
                            //TODO: strings extracted can be normalized before this, such as different data formats, "Male" to "M", "Female" to "F", 多余的标点符号了， etc.
                            //TODO：举个例子，像born_in这个关系，因为后面跟的是实体，在000里面是http://blabla/Paris,在001里面就是http://blabla/item36259425之类，虽然实际上是一个东西，但字符串比较结果会不一样，此处可改进，不好改进就写近报告里面的待改进部分
                            JaroWinkler jaroWinkler = new JaroWinkler();
                            double similarity = jaroWinkler.score(str1, str2);
                            if (similarity < similarityThreshold) {
                                same = false;
                            }
                        }
                    }
                }
            }
            if (same) {
                truePositive += 1;
            } else {
                falseNegative += 1;
            }

        }

        for (Pair pair : incorrectPairs) {
            boolean same = false;
            Resource resource1 = model0.getResource(pair.getEntity1());
            StmtIterator it1 = resource1.listProperties();
            while (it1.hasNext()) {
                Statement st1 = it1.nextStatement();
                if (functionalProperties.contains(st1.getPredicate().toString())) {
                    String str1 = st1.getObject().toString();
                    Resource resource2 = model1.getResource(pair.getEntity2());
                    StmtIterator it2 = resource2.listProperties();
                    while (it2.hasNext()) {
                        Statement st2 = it2.nextStatement();
                        if (st2.getPredicate().toString().equals(st1.getPredicate().toString())) {
                            String str2 = st2.getObject().toString();
                            //TODO: strings extracted can be normalized before this, such as different data formats, "Male" to "M", "Female" to "F", 多余的标点符号了， etc.
                            JaroWinkler jaroWinkler = new JaroWinkler();
                            double similarity = jaroWinkler.score(str1, str2);
                            if (similarity < similarityThreshold) {
                                same = true;
                            }
                        }
                    }
                }
            }
            if (same){
                trueNegative += 1;
            } else {
                falsePositive += 1;
            }
        }

        //TODO：不知道接下来三行写的对不对
        double precision = truePositive / (truePositive + falsePositive);
        double recall = truePositive / (truePositive + falseNegative);
        double f1 = 2 * ((precision * recall) / (precision + recall));

        System.out.println("Precision: " + precision);
        System.out.println("Recall: " + recall);
        System.out.println("f1: " + f1);


    }



}
